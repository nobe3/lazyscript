#Bismillah
#Assalamu-Alaikum 

[+] Termux-Lazyscript :-
 
   This tool is specially Designed for Termux Beginner 
   users.This tool is very helpfull for Beginners.here
   simply type number of tool to use after usage press
   enter to launch again Termux-Lazyscript.

[+] Author :-

   Name : Mujeeb
   Youtube : www.youtube.com/TechnicalMujeeb
   Github : https://github.com/TechnicalMujeeb/Termux-Lazyscript.git
   whatsapp : Termux cyber   

[+] Installation :-
  
    apt update && apt upgrade
    apt install git   
    apt install python2
    git clone https://github.com/TechnicalMujeeb/Termux-Lazyscript.git
    cd Termux-Lazyscript
    chmod +x *
    sh setup.sh

[+] usage :-

    python2 ls.py
    (here simply type number to use that tool)
    Enjoy.
